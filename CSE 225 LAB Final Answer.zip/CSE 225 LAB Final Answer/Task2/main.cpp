#include <iostream>
#include"BinarySearchTree.h"
using namespace std;

int main()
{
    TreeType<int> in;

    in.InsertItem(4);
    in.InsertItem(9);
    in.InsertItem(2);
    in.InsertItem(7);
    in.InsertItem(3);
    in.InsertItem(11);
    in.InsertItem(17);
    in.InsertItem(0);
    in.InsertItem(5);
    in.InsertItem(1);

    if(in.IsEmpty())
    {
        cout<<"Tree Is Empty"<<endl;
    }
    else
    {
        cout<<"Tree Is Not Empty"<<endl;
    }
    cout<<"Height Of Tree: "<<in.findHeight()<<endl;
    cout<<"Number of leaf Node: "<<in.CountLeafNode()<<endl;
    in.ResetTree(IN_ORDER);
    cout<<"The Tree is: ";
    bool finished=0;
    while(!finished)
    {
        int value;
        in.GetNextItem(value,IN_ORDER,finished);
        cout<<value<<" ";
    }
    cout<<endl;

    return 0;
}
