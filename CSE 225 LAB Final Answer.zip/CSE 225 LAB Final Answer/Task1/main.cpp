#include <iostream>
#include"QueueType.h"
using namespace std;

int main()
{
    QueueType<char> in;


    try{
        in.EnQueue('C');
        in.EnQueue('S');
        in.EnQueue('E');
        in.EnQueue('2');
        in.EnQueue('2');
        in.EnQueue('5');
    }
    catch(FullQueue& e)
    {
        cout<<"Queue is full";
    }
    cout<<"Queue Before Reverse: ";
    try
    {
        in.print();
    }
    catch(EmptyQueue& e)
    {
        cout<<"Queue is Empty";
    }

    cout<<"Queue After Reverse: ";

    try
    {
        in.ReverseQue(in);
        in.print();
    }
    catch(EmptyQueue& e)
    {
        cout<<"Queue is Empty";
    }

}
